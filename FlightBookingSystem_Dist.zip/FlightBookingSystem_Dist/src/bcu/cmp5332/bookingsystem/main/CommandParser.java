package bcu.cmp5332.bookingsystem.main;

import bcu.cmp5332.bookingsystem.commands.*;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.List;

public class CommandParser {

	public static Command parse(String line) throws IOException, FlightBookingSystemException {
		try {
			String[] parts = line.split(" ", 3);
			String cmd = parts[0];

			if (cmd.equals("addflight")) {
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				System.out.print("Flight Number: ");
				String flighNumber = br.readLine();
				System.out.print("Origin: ");
				String origin = br.readLine();
				System.out.print("Destination: ");
				String destination = br.readLine();
				System.out.print("Price: ");
				int pirce = Integer.parseInt(br.readLine());
				System.out.print("Seats: ");
				int seats = Integer.parseInt(br.readLine());

				LocalDate departureDate = parseDateWithAttempts(br);
				return new AddFlight(flighNumber, origin, destination,pirce,seats, departureDate);
			} else if (cmd.equals("addcustomer")) {
				BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
				System.out.print("Customer name");
				String name = br.readLine();
				System.out.print("Phone number");
				String phone = br.readLine();
				System.out.print("Email address");
				String email = br.readLine();

				return new AddCustomer(name,phone,email);

			} else if (cmd.equals("loadgui")) {
				return new LoadGUI();
			} else if (parts.length == 1) {
				if (line.equals("listflights")) {
					return new ListFlights();
				} else if (line.equals("listcustomers")) {
					return new ListCustomers();

				} else if (line.equals("help")) {
					return new Help();
				}
			} else if (parts.length == 2) {
				int id = Integer.parseInt(parts[1]);

				if (cmd.equals("showflight")) {

					return new ShowFlight(id);
				} else if (cmd.equals("showcustomer")) {

					return new ShowCustomer(id);
				}
			} else if (parts.length == 3) {
				int patronID = Integer.parseInt(parts[1]);
				int bookID = Integer.parseInt(parts[2]);

				if (cmd.equals("addbooking")) {
					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

					LocalDate departureDate = parseDateWithAttempts(br);
					return new AddBooking(patronID,bookID,departureDate);
				} else if (cmd.equals("editbooking")) {
					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

					LocalDate departureDate = parseDateWithAttempts(br);
					return new UpdateBooking(patronID,bookID,departureDate);

				} else if (cmd.equals("cancelbooking")) {
					BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

					LocalDate departureDate = parseDateWithAttempts(br);
					return new CancelBooking(patronID,bookID,departureDate);

				}
			}
		} catch (NumberFormatException ex) {

		}

		throw new FlightBookingSystemException("Invalid command.");
	}

	private static LocalDate parseDateWithAttempts(BufferedReader br, int attempts) throws IOException, FlightBookingSystemException {
		if (attempts < 1) {
			throw new IllegalArgumentException("Number of attempts should be higher that 0");
		}
		while (attempts > 0) {
			attempts--;
			System.out.print("Departure Date (\"YYYY-MM-DD\" format): ");
			try {
				LocalDate departureDate = LocalDate.parse(br.readLine());
				return departureDate;
			} catch (DateTimeParseException dtpe) {
				System.out.println("Date must be in YYYY-MM-DD format. " + attempts + " attempts remaining...");
			}
		}

		throw new FlightBookingSystemException("Incorrect departure date provided. Cannot create flight.");
	}

	private static LocalDate parseDateWithAttempts(BufferedReader br) throws IOException, FlightBookingSystemException {
		return parseDateWithAttempts(br, 3);
	}
}
