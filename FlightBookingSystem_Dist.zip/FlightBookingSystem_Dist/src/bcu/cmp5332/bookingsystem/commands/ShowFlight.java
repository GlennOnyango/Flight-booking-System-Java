package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.time.format.DateTimeFormatter;

public class ShowFlight implements Command {
    int flightId;

    public ShowFlight(int flightId) {
        this.flightId = flightId;
    }

    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {

        Flight flight = flightBookingSystem.getFlightByID(flightId);
        System.out.print("Flight #" + flight.getId() + " - " + flight.getFlightNumber() + " - " + flight.getOrigin() + " to "
                + flight.getDestination() + " on " + flight.getDepartureDate()+"\n");

    }
}
