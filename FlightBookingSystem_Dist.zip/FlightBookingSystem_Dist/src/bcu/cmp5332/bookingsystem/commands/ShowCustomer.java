package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

public class ShowCustomer implements Command {
    public ShowCustomer(int customerId) {
        this.customerId = customerId;
    }

    private  int customerId;

    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {

        Customer customer = flightBookingSystem.getCustomerByID(customerId);

        System.out.print( "Customer #" + customer.getId() + " - " + customer.getName() + " - " + customer.getPhone() );
    }
}
