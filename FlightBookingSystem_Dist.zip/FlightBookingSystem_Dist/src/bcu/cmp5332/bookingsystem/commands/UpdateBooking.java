package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.time.LocalDate;

public class UpdateBooking implements Command {
    private  int customerId,flightId;
    private LocalDate departureDate;

    public UpdateBooking(int customerId, int flightId, LocalDate departureDate) throws FlightBookingSystemException {
        this.customerId = customerId;
        this.flightId = flightId;
        this.departureDate = departureDate;
        FlightBookingSystem bs = new FlightBookingSystem();
        //bs.getBooking().remove(bs.getCustomerByID(customerId));
    }


    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        Customer customer = flightBookingSystem.getCustomerByID(customerId);
        Flight flight = flightBookingSystem.getFlightByID(flightId);
        Booking booking = new Booking(customer,flight,departureDate);
        customer.addBooking(booking);
        flight.addPassenger(customer);
        System.out.println("Booking was updated successfully to"+flightBookingSystem.getCustomerByID(customerId));
    }
}
