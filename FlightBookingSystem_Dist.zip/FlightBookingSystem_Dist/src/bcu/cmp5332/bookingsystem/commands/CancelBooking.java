package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.Booking;
import bcu.cmp5332.bookingsystem.model.Customer;
import bcu.cmp5332.bookingsystem.model.Flight;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

import java.time.LocalDate;

public class CancelBooking implements Command {
 private int customerId,flightId;
 private LocalDate bookingdate;

    public CancelBooking(int customerId, int flightId, LocalDate bookingdate) {
        this.customerId = customerId;
        this.flightId = flightId;
        this.bookingdate = bookingdate;
    }

    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {
        Customer customer = flightBookingSystem.getCustomerByID(customerId);
        Flight flight =  flightBookingSystem.getFlightByID(flightId);
        Booking booking = new Booking(customer,flight,bookingdate);
        customer.cancelBooking(booking);
        flight.removePassenger(customer);
        System.out.print("FLight for "+flightBookingSystem.getCustomerByID(customerId)+" canceled");

    }
}
