package bcu.cmp5332.bookingsystem.commands;

import bcu.cmp5332.bookingsystem.main.FlightBookingSystemException;
import bcu.cmp5332.bookingsystem.model.FlightBookingSystem;

public class DeleteFlight implements Command {
    private int flightID;

    public DeleteFlight(int flightID) {
        this.flightID = flightID;
    }

    @Override
    public void execute(FlightBookingSystem flightBookingSystem) throws FlightBookingSystemException {

        flightBookingSystem.deleteFLight(flightBookingSystem.getFlightByID(flightID));
    }
}
